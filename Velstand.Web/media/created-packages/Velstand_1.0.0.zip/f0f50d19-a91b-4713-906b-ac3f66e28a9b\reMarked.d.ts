﻿// 仮
declare class reMarked {
    constructor(opts: any);
    render(any);
}